import torch
import torch.nn as nn
import torch.optim as optim
from torch.utils.data import DataLoader, Dataset
import pandas as pd
import numpy as np

# 读取数据
data = pd.read_csv('recommend_data.csv')

# 将用户和商品映射到连续的ID
user_ids = data['Customer ID'].unique()
item_ids = data['Item Purchased'].unique()
user_id_map = {user_id: idx for idx, user_id in enumerate(user_ids)}
item_id_map = {item_id: idx for idx, item_id in enumerate(item_ids)}

data['user_idx'] = data['Customer ID'].map(user_id_map)
data['item_idx'] = data['Item Purchased'].map(item_id_map)

# 构建数据集
class RecommendationDataset(Dataset):
    def __init__(self, interactions):
        self.users = interactions['user_idx'].values
        self.items = interactions['item_idx'].values
        self.ratings = interactions['Review Rating'].values.astype(np.float32)

    def __len__(self):
        return len(self.users)

    def __getitem__(self, idx):
        return self.users[idx], self.items[idx], self.ratings[idx]

# 数据集和DataLoader
dataset = RecommendationDataset(data)
data_loader = DataLoader(dataset, batch_size=64, shuffle=True)

# 定义模型
class NCF(nn.Module):
    def __init__(self, num_users, num_items, embedding_dim):
        super(NCF, self).__init__()
        self.user_embedding = nn.Embedding(num_users, embedding_dim)
        self.item_embedding = nn.Embedding(num_items, embedding_dim)

        self.fc1 = nn.Linear(embedding_dim * 2, 128)
        self.fc2 = nn.Linear(128, 64)
        self.fc3 = nn.Linear(64, 1)

        self.activation = nn.ReLU()

    def forward(self, user_indices, item_indices):
        user_embeds = self.user_embedding(user_indices)
        item_embeds = self.item_embedding(item_indices)
        
        x = torch.cat([user_embeds, item_embeds], dim=-1)
        x = self.activation(self.fc1(x))
        x = self.activation(self.fc2(x))
        x = torch.sigmoid(self.fc3(x))

        return x

# 初始化模型
num_users = len(user_ids)
num_items = len(item_ids)
embedding_dim = 32
model = NCF(num_users, num_items, embedding_dim)

# 定义损失函数和优化器
criterion = nn.MSELoss()
optimizer = optim.Adam(model.parameters(), lr=0.001)

# 训练模型
epochs = 5
model.train()
for epoch in range(epochs):
    epoch_loss = 0
    for user_indices, item_indices, ratings in data_loader:
        user_indices = user_indices.long()
        item_indices = item_indices.long()

        predictions = model(user_indices, item_indices).squeeze()
        loss = criterion(predictions, ratings)

        optimizer.zero_grad()
        loss.backward()
        optimizer.step()

        epoch_loss += loss.item()

    print(f"Epoch {epoch+1}/{epochs}, Loss: {epoch_loss/len(data_loader):.4f}")

# 推荐函数
def recommend_items_ncf(user_id, model, top_n=5):
    user_idx = user_id_map[user_id]
    all_items = torch.arange(num_items)
    user_tensor = torch.tensor([user_idx] * num_items)

    model.eval()
    with torch.no_grad():
        scores = model(user_tensor, all_items).squeeze()
        top_items = torch.topk(scores, top_n).indices

    recommended_items = [item_ids[idx] for idx in top_items]
    return recommended_items

# 示例推荐
recommendations = recommend_items_ncf(user_id=1, model=model)
print(f"Recommended items for Customer 1: {recommendations}")