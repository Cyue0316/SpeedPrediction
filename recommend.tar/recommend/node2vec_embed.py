from node2vec import Node2Vec
import networkx as nx
import pandas as pd



data = pd.read_csv('recommend_data.csv')

# 构建用户-商品二分图
G = nx.Graph()
for _, row in data.iterrows():
    G.add_edge(f"user_{row['Customer ID']}", f"item_{row['Item Purchased']}")

# 使用 Node2Vec 生成嵌入
node2vec = Node2Vec(G, dimensions=64, walk_length=30, num_walks=200, workers=4)
model = node2vec.fit(window=10, min_count=1, batch_words=4)

# 推荐函数
def recommend_items_graph(user_id, model, top_n=5):
    user_key = f"user_{user_id}"
    similar_items = model.wv.most_similar(user_key, topn=top_n)
    recommendations = [item for item, _ in similar_items if item.startswith("item_")]
    return recommendations

# 示例推荐
recommendations = recommend_items_graph(user_id=1, model=model)
print(f"Recommended items for Customer 1: {recommendations}")
