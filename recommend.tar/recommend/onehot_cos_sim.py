import pandas as pd
from sklearn.metrics.pairwise import cosine_similarity
from sklearn.preprocessing import OneHotEncoder

# 读取数据
data = pd.read_csv('recommend_data.csv')

# 编码商品特征
item_features = data[['Category', 'Season', 'Color', 'Size']]
encoder = OneHotEncoder()
item_encoded = encoder.fit_transform(item_features).toarray()

# 计算商品相似度
item_similarity = cosine_similarity(item_encoded)

# 推荐函数
def recommend_items(customer_id, data, item_similarity, top_n=5):
    customer_items = data[data['Customer ID'] == customer_id]['Item Purchased']
    customer_indices = [data[data['Item Purchased'] == item].index[0] for item in customer_items]
    
    scores = item_similarity[customer_indices].mean(axis=0)
    top_indices = scores.argsort()[-top_n:][::-1]
    
    recommended_items = data.iloc[top_indices]['Item Purchased'].unique()
    return recommended_items

# 示例推荐
recommendations = recommend_items(customer_id=10, data=data, item_similarity=item_similarity)
print(f"Recommended items for Customer 1: {recommendations}")
